﻿using System;

#pragma warning disable CS1591

namespace RimArchive
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct)]
    public class HotSwappableAttribute : Attribute
    {
    }
}
