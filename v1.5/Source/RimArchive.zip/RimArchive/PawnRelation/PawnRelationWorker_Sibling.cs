﻿namespace RimArchive;

public class PawnRelationWorker_Sibling : PawnRelationWorker
{

}
