﻿namespace RimArchive;

public class PawnRelationWorker_SameClub : PawnRelationWorker
{
}
