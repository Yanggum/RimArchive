﻿namespace RimArchive;


[DefOf]
public static class ThingDefOf
{
    public static ThingDef Bombardment_beacon;
    public static ThingDef BA_HOD_Pillar;
    public static ThingDef Shittim_Chest_Apparel;
}
