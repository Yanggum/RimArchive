﻿namespace RimArchive;

public class CompAbilityEffect_PowerBeam : CompAbilityEffect_WithDest
{
    /*想法：
     * 感觉从本体到目标地点的光束可能看起来会有点问题？先照着帝国拓展的天降光束来
     */

}
