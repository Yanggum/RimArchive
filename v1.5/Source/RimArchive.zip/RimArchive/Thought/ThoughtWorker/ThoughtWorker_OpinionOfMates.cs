﻿namespace RimArchive;

//同一部活？
public class ThoughtWorker_OpinionOfMates
{
}
