﻿namespace RimArchive.Bosses;

public class Pillar : Building
{
}
