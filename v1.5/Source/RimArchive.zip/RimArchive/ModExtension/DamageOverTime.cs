﻿namespace RimArchive.ModExtension;

public class DamageOverTime : DefModExtension
{
    public DamageDef DamageDef;
    public float InitialDamage;
    public float TickDamage;
    public float DamageInterval;
    public float Duration;
}
