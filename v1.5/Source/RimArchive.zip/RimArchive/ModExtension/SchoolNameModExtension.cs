﻿
#pragma warning disable CS0169
namespace RimArchive
{
    /// <summary>
    /// Currently not used.
    /// </summary>
    public class RA_StudentModExtension : DefModExtension
    {
        private string School;
    }
}
