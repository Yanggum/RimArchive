﻿namespace RimArchive;

//仅用于武器（持有该武器的"对应学生"解锁"对应技能"）
public class AbilityModExtension : DefModExtension
{
    public AbilityDef Ability;
    public StudentDef Student;
}

