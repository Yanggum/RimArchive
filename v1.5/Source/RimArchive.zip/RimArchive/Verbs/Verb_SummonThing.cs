﻿namespace RimArchive;

public class Verb_SummonThing : Verb_CastAbility
{

}
